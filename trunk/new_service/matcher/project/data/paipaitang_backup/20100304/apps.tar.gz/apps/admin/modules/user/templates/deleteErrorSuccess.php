<div class="contentBox">
<p>该项目有关联数据，不能删除！</p>
<p><a href="javascript:window.history.go(-1)">返回上一页</a></p>
</div><!-- EndOf contentBox -->


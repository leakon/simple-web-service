<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
  <head>
    <?php include_http_metas() ?>
    <?php include_metas() ?>
    <?php include_title() ?>
    <link rel="shortcut icon" href="/favicon.ico" />

<script type="text/javascript" src="/matcher/js/mootools-1.2.1-core-nc.js"></script>
<script type="text/javascript" src="/matcher/js/main.js?v20100203"></script>
<script type="text/javascript" src="/matcher/js/item.js"></script>

<link rel="stylesheet" type="text/css" media="screen" href="/matcher/css/main.css" />

<script>
if (top.location == window.location) {

//	top.location	= '/admin/index.php';


}
</script>

</head>
<body>
	<div id="mainBody">
	  	<table id="mainTable" cellspacing="1">
	  	<tbody>
	  		<tr>
	  			<td class="content">
	    				<?php echo $sf_content ?>
	  			</td>
	  		</tr>
		</tbody>
	  	</table>
	</div>


</body>
</html>

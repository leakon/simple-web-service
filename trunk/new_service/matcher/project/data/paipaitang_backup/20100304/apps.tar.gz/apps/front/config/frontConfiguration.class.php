<?php

class frontConfiguration extends sfApplicationConfiguration
{
  public function configure()
  {
  }
}

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <?php include_http_metas() ?>
    <?php include_metas() ?>
    <?php include_title() ?>
    <link rel="shortcut icon" href="/favicon.ico" />

<script type="text/javascript" src="/matcher/js/mootools-1.2.1-core-nc.js"></script>
<script type="text/javascript" src="/matcher/js/main.js"></script>
<script type="text/javascript" src="/matcher/js/item.js"></script>

<link rel="stylesheet" type="text/css" media="screen" href="/admin/images/admin.css" />


<script>
if (top.location == window.location) {


	top.location	= '/admin/index.php';


}
</script>


</head>
<body>

		<?php echo $sf_content ?>

</body>
</html>

